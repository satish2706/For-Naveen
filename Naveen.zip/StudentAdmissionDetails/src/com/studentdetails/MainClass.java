package com.studentdetails;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		String name;
		int age=0;
		char gen;
		String address;
		String fatherName;
		String motherName;
		int rollNo;
		float avgMarks;
		float attendance;
		 String nameOfMember;
		 String designation;
		 String position;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Name");
		name=sc.nextLine();
		System.out.println("Enter Your Age ");
		age=sc.nextInt();
		System.out.println("Enter Your Gender M/F ");
		gen=sc.next().charAt(0);
		System.out.println("Enter Your Address ");
		address=sc.next();
		System.out.println("Enter Your Father name ");
		fatherName=sc.next();
		System.out.println("Enter Your Mother name ");
		motherName=sc.next();
		System.out.println("Enter Your Roll No ");
		rollNo=sc.nextInt();
		System.out.println("Enter Your Average Marks ");
		avgMarks=sc.nextFloat();
		System.out.println("Enter Your Attendace ");
		attendance=sc.nextFloat();
		System.out.println("Enter Name Of the member ");
		nameOfMember=sc.next();
		System.out.println("Enter Designation ");
		designation=sc.next();
		System.out.println("Enter Position ");
		position=sc.next();
		Student services=new Student(name, age, gen, address,fatherName,  motherName);
		System.out.println("\t\t\t\t\t\t\t"+"STUDENT PERSONAL DETAILS");
		System.out.println(services);
		System.out.println("\n");
		System.out.println("\n");
		StudentEducationalDetails services2=new StudentEducationalDetails(rollNo,avgMarks,attendance);
		System.out.println("\t\t\t\t\\t\t\t"+"STUDENT EDUCATIONAL DETAILS");
		System.out.println(services2);
		System.out.println("\n");
		System.out.println("\n");
		StaffDetails staff= new StaffDetails(nameOfMember, designation, position);
		System.out.println("\t\t\t\t\t\t\t"+"STAFF DETAILS");
		System.out.println(staff);
	}

}
