package com.studentdetails;

public class StaffDetails {
	private String nameOfMember;
	private String designation;
	private String position;
	public StaffDetails(String nameOfMember, String designation, String position) {
		super();
		this.nameOfMember = nameOfMember;
		this.designation = designation;
		this.position = position;
	}
	@Override
	public String toString() {
		return "Name Of the Member=" + nameOfMember +"\n"+ "Designation=" + designation + "\n"+"His Position=" + position
				+ "]";
	}
}
