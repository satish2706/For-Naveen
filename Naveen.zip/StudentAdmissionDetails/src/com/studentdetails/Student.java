package com.studentdetails;

public class Student {

	private String name;
	private int age;
	private char gen;
	private String address;
	private String fatherName;
	private String motherName;
	public Student(String name, int age, char gen, String address, String fatherName, String motherName) {
		super();
		this.name = name;
		this.age = age;
		this.gen = gen;
		this.address = address;
		this.fatherName = fatherName;
		this.motherName = motherName;
	}
	@Override
	public String toString() {
		return "Name Of  The Student=" + name +"\n"+ "Age=" + age + "\n"+"Student is =" + gen +"\n"+ "Address Of The student=" + address +"\n"+ "Fathers Name="
				+ fatherName +"\n"+ "Mother's Name=" + motherName + "]";
	}
	
	
}
