package com.studentdetails;

public class StudentEducationalDetails {
private int rollNo;
private float avgMarks;
private float attendance;
public StudentEducationalDetails(int rollNo, float avgMarks, float attendance) {
	super();
	this.rollNo = rollNo;
	this.avgMarks = avgMarks;
	this.attendance = attendance;
}
@Override
public String toString() {
	return "Roll No of the student=" + rollNo +"\n"+ "Average MArks Of Student=" + avgMarks + "\n"+"Attendance of Student=" + attendance
			;
}

}
