package com.cg.payroll.client;

import com.cg.payroll.util.PayrollUtil;

public class TestMain {

	public static void main(String[] args) {
		PayrollUtil.getDBConnectoin();
		System.out.println("Connection is Open");
	}
}
