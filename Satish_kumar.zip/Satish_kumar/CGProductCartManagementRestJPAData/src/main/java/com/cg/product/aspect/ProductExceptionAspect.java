package com.cg.product.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import com.cg.product.exception.ProductDetailsNotFoundException;
import com.cg.product.response.CustomeResponse;

// Aspect annotation we can declare a new aspect
//we can easily automate the conversion of Java runtime exceptions. 
//This simplifies our code by removing try/catch blocks that would otherwise be required for exception translation.
@ControllerAdvice
public class ProductExceptionAspect {

	@ExceptionHandler(ProductDetailsNotFoundException.class)
	public ResponseEntity<CustomeResponse>  handelMovieDetailsNotFoundException(Exception e) {
	CustomeResponse response=new CustomeResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
	return new ResponseEntity<CustomeResponse>(response,HttpStatus.EXPECTATION_FAILED);
	}	
	
}
