package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.product.beans.Product;
import com.cg.product.exception.ProductDetailsNotFoundException;
import com.cg.product.services.ProductService;


@Controller // @Controller annotation is used to mark any java class as a controller class. 
//The @RequestMapping annotation is used to map the web request "/acceptProductDetails" to the UserController class. 
public class ProductServiceController {
@Autowired//The @Autowired annotation provides more fine-grained control over where and how autowiring should be accomplished. 
//The @Autowired annotation can be used to autowire bean on the setter method just like @Required annotation, constructor, a property or methods with arbitrary names and/or multiple arguments
ProductService productService;	

//@RequestMapping is one of the most widely used Spring MVC annotation. org.springframework.web.bind.annotation.RequestMapping annotation is used to map web requests onto specific handler classes and/or handler methods.
//@RequestMapping can be applied to the controller class as well as methods.
@RequestMapping(value= {"/acceptProductDetails"},method=RequestMethod.POST ,
produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
	product=productService.acceptProductDetails(product);
	return new ResponseEntity<>("Product Details Succesfully Added product Id:-"+product.getId(),HttpStatus.OK);
}


@RequestMapping(value= {"/removeProductDetails"},method=RequestMethod.DELETE ,
produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> removeProductDetails(@RequestParam int  id) throws ProductDetailsNotFoundException{
	productService.removeProductDetails(id);
	return new ResponseEntity<>("Product Details Succesfully Removed :-",HttpStatus.OK);
}

@RequestMapping(value= {"/getAllProductDetails"},method=RequestMethod.GET ,
produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<List<Product>> getProductDetailsPathParam(){
	return new ResponseEntity<List<Product>>(productService.getAllProducts(),HttpStatus.OK);
}

//used to get product details against a id
@RequestMapping(value= {"/getProductDetails/{id}"},method=RequestMethod.GET ,
produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<Product> getProductDetailsPathParam(@PathVariable(value="id")int id) throws ProductDetailsNotFoundException {
	Product product=productService.getProductDetails(id);
	return new ResponseEntity<Product>(product,HttpStatus.OK);
}
//used to update the the data using put and by providing Id
@RequestMapping(value="/updateProductDetails", method=RequestMethod.PUT, consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String>updateProductDetails(@RequestParam  int id, Product product) throws ProductDetailsNotFoundException{
	product=productService.updateProductDetails(id, product);
	return new ResponseEntity<>("Product details successfully Updated Product Id:- "+product.getId(),HttpStatus.OK);
}


}
