package com.cg.product.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.product.beans.Product;

//JPA Respository provides four CRUD operations to us
public interface ProductDAO  extends JpaRepository<Product, Integer>{

}
